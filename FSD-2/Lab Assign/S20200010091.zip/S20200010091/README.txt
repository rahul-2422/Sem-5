FSD ASSIGNMENT
-------------------------
NAME     : Katinni Rahul
ROLL No. : S20200010091
-------------------------


-------------------------------------------------------------------------------------------------------------------------------------------------
STEPS TO RUN THE APP
-------------------------------------------------------------------------------------------------------------------------------------------------

NOTE : Install'CORS' Extension in you browser and in the extensions 'options page' select the 'Access-Control-Allow-Headers' box

Step 1: Unzip the S20200010091.zip file and open the unzipped folder in VS code
Step 2: change the directory to the 'backend' directory present in the S20200010091 folder.
Step 3: run the command 'npm i --force' to install all the dependencies
Step 4: run the command 'npm start' to start the server
Step 5: change the directory to the 'frontend' directory present in the S20200010091 folder.
Step 6: run the command 'npm i --force' to install all the dependencies
Step 7: run the command 'npm start' to start the react app.
-------------------------------------------------------------------------------------------------------------------------------------------------
 