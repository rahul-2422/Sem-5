const mongoose = require("mongoose");
exports.dbconnection = () => {
    mongoose
        .connect("mongodb+srv://vd2507:vaibhav@cluster0.nmxul8d.mongodb.net/FoodApp", {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        })
        .then(() => {
            console.log("Connection to MONGO successful");
        })
        .catch((err) => {
            console.log(err);
        });
};
// mongodb://localhost:27017/FoodApp