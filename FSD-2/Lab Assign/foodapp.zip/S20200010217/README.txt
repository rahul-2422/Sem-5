FSD ASSIGNMENT
-------------------------
NAME     : Vaibhav Dasari
ROLL No. : S20200010217
-------------------------


-------------------------------------------------------------------------------------------------------------------------------------------------
INSTRUCTIONS TO RUN THE APP
-------------------------------------------------------------------------------------------------------------------------------------------------

NOTE : INSTALL THE EXTENSION 'CORS' IN YOUR BROWSER AND IN THE EXTENSION'S 'OPTIONS PAGE' CHECK THE 'Access-Control-Allow-Headers' box

Step 1: change the directory to the 'backend' directory present in the zip file uploaded.
Step 2: run the command 'npm install' to install all the dependencies
Step 3: run the command 'node server.js' to start the server
Step 4: change the directory to the 'backend' directory present in the zip file uploaded.
Step 5: run the command 'npm install' to install all the dependencies
Step 6: run the command 'npm start' to start the react app.
-------------------------------------------------------------------------------------------------------------------------------------------------
 