import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

export default function Header() {
    const cartItems = useSelector((state) => state.cart.cartItems);
    return (
        <nav className='navbar navbar-expand-lg navbar-light bg-light'>
            <div className='container'>
                <Link to='/' className='navbar-brand' style={{ fontWeight: "bold" }}>
                    <img style={{ width: "40px", marginRight: "10px" }} alt="food" src='/images/peach.png' />
                    ZWIGGY
                </Link>

                <Link to='/cart' className='btn btn-outline-dark'>
                    <i className='fa-solid fa-cart-shopping'></i>
                    Cart
                    <span className='badge bg-dark text-white ms-1 rounded-pill'>{cartItems.length}</span>
                </Link>
            </div>
        </nav>
    );
}
