import React, { useState } from 'react'

function RegistrationForm({chnageHandler, data, submitHandler}) {

    
    return (
        <div>
            <form onSubmit={submitHandler}>
                <div>
                    <label>First Name : </label>
                    <input type='text' name='firstName' value={data.firstName} onChange={chnageHandler} />
                </div>
                {/* <br/> */}
                <div>
                    <label>Middle Name : </label>
                    <input type='text' name='middleName' value={data.middleName} onChange={chnageHandler} />
                </div>
                {/* <br/> */}
                <div>
                    <label>Last Name : </label>
                    <input type='text' name='lastName' value={data.lastName} onChange={chnageHandler} />
                </div>
                {/* <br/> */}

                <div>
                <label>Course : </label>
                    <select value = {data.course} name = 'course' onChange={chnageHandler}>
                        <option value = 'cse'>CSE</option>
                        <option value = 'ece'>ECE</option>
                    </select>
                </div>

                <div onChange={chnageHandler}>
                    <label>Male</label>
                    <input type='radio' name = 'gender' value = 'male' />
                    <label>Female</label>
                    <input type='radio' name = 'gender' value = 'female' />
                    <label>Other</label>
                    <input type='radio' name = 'gender' value = 'other' />

                    {/* {console.log(gender)} */}
                </div>

                <div>
                    <label>Phone : </label>
                    <select >
                        <option value = '+91'>+91</option>
                        <option value = '+21'>+21</option>
                    </select>
                    <input type = 'text' name = 'phone' value = {data.phone} onChange={chnageHandler} />
                </div>

                <div>
                    <label>address : </label>
                    <textarea value = {data.address} name = 'address' onChange={chnageHandler}></textarea>
                </div>

                <div>
                    <label>Email : </label>
                    <input type='text' name='email' value={data.email} onChange={chnageHandler} />
                </div>

                <div>
                    <label>Password : </label>
                    <input type='text' name='password' value={data.password} onChange={chnageHandler} />
                </div>

                <div>
                    <label>Retype Password : </label>
                    <input type='text' name='repassword' value={data.repassword} onChange={chnageHandler} />
                </div>

                <div>
                    <button type='submit'>submit</button>
                </div>

            </form>
        </div>
    )
}

export default RegistrationForm