import React, { useState } from 'react'
import './App.css';
import RegistrationForm from './components/RegistrationForm';

function App() {

	const [data, setData] = useState({firstName: '', middleName: '', lastName: '', course: '', gender: '', phone: '', address: '', email: '', password: '', repassword: ''})

    const chnageHandler = (e) => {
        setData({... data, [e.target.name]: e.target.value})
    }

	const handleSubmit = (e) => {
		e.preventDefault()
		console.log(...[data])
	}

	return (
		<div className="App">
			<RegistrationForm chnageHandler = {chnageHandler} data = {data} submitHandler = {handleSubmit}/>
		</div>
	);
}

export default App;
