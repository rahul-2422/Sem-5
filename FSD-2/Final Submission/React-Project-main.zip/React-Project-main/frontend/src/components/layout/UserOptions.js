import React from 'react'

const UserOptions = () => {
  return (
    <div><h1>UserOptions</h1></div>
  )
}

export default UserOptions