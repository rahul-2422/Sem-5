import React from 'react'
import ProductCard from './layout/ProductCard'

const FeaturedProducts = (props) => {
  return (
      <>
      <ProductCard />
      </>
  )
}

export default FeaturedProducts