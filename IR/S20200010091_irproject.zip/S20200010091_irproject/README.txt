IR Project : Ad Retrieval


Our Project is Ad retrieval, we retrieve Ad's based on the query provided by the user.


Steps to run the code:

* First unzip the S20200010091_code.zip present in the S20200010091_irproject.zip
* After unzipping into a folder of your choice enter into the ir_final directory present in the unzipped folder.
* Once here open this directory in vs code.
* Now the code is ready to execute and we can give the query by runnin the query_processing.py file.
* Here the previously entered N-Gram value is 2.
* If you want to change it please run the permuterm.py file.
* After the query_processing.py executed to get the result run the ranking.py file.
* The top 10 relevant docs for the given query are written into the ranking.json file present in the jsonFiles directory.
* Then run the evaluation.py file to provide relvance feedback and get the precision recall metrics of the ir system.
